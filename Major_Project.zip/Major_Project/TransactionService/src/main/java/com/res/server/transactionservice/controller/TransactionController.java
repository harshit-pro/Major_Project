package com.res.server.transactionservice.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.res.server.transactionservice.dto.TransactionCreateRequest;
import com.res.server.transactionservice.service.TransactionServices;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;

@RestController
@RequestMapping("/transaction")
public class TransactionController {

    @Autowired
    private TransactionServices transactionServices;

    @PostMapping("/initiate")
    private String initiateTransaction(@RequestBody @Valid TransactionCreateRequest transactionCreateRequest) throws JsonProcessingException {
    //transaction tabhi ho payega  jab user pehle se logged in ho aur uska wallet balance sufficient ho
    // security context holder se user ki details le lo
    // yaha par transactions object me senderId ko set kar do jo ki user ki mobile number se aayega
    // aur receiverId ko bhi set kar do jo ki receiver ki mobile number se aayega
    // i get the user details from current logged in user from security context holder
    User sender= (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        System.out.println("Sender Username: " + sender.getUsername());
        System.out.println("Receiver ID: " + transactionCreateRequest.getReceiverId());
    return transactionServices.transact(transactionCreateRequest, sender.getUsername());
}
}
