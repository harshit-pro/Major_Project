package com.res.server.transactionservice.model;


public enum TransactionStatus {
    PENDING,
    SUCCESS,
    FAILED
}
