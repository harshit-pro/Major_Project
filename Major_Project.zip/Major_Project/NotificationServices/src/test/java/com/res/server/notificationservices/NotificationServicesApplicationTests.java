package com.res.server.notificationservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificationServicesApplicationTests {

    @Test
    void contextLoads() {
    }

}
