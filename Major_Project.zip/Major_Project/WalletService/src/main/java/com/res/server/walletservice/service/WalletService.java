package com.res.server.walletservice.service;
import com.res.server.walletservice.model.Wallet;
import com.res.server.walletservice.repository.WalletRepository;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class WalletService {
    Long initialBalance=2000L; // Initial balance for the wallet, can be set to any value
    @Autowired
    private WalletRepository walletRepository;

    @KafkaListener(topics = {"user-created"}, groupId = "jbdl123")
    public void createWallet(String message) { // message is the user data in JSON format
try {

    // here we are parsing the JSON message to a JSONObject
    JSONObject userJsonObject = (org.json.simple.JSONObject) new JSONParser().parse(message);

    String mobileNumber= userJsonObject.get("phone").toString();

    Wallet wallet= Wallet.builder() //  yaha par we are creating a wallet object
            // using the builder pattern matlab ki we are using the builder pattern to create a wallet object
            // why because of this we can create a wallet object with the required fields
            .walletId(mobileNumber)
            .currency("INR") // Assuming the currency is Indian Rupee
            .balance(initialBalance) // Initial balance is set to 0
            .build();
    walletRepository.save(wallet);

}catch (ParseException e){
    throw  new RuntimeException("Error parsing JSON message: " + e.getMessage());
}


    }
    public String updateWallet(String senderId, String receiverId, Long amount) {
        // This method will be used to update the wallet balance after a transaction
        // For now, we will just print the details
        Wallet senderWallet = walletRepository.findWalletByWalletId(senderId);
        Wallet receiverWallet = walletRepository.findWalletByWalletId(receiverId);
        if(senderWallet==null || receiverWallet==null || senderWallet.getBalance() < amount) {
            throw new RuntimeException("Wallet not found for sender or receiver");
        }
        // Update the sender's wallet balance
        walletRepository.updateWallet(senderId, -amount);
        // Update the receiver's wallet balance
        walletRepository.updateWallet(receiverId, amount);

        return "Wallet updated successfully for transaction ID: " ;

    }


}
