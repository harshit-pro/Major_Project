package com.major.userservice.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.major.userservice.dto.CreateUserRequest;
import com.major.userservice.dto.GetUserResponse;
import com.major.userservice.models.User;
import com.major.userservice.service.UserService;
import com.major.userservice.utils.Utils;
import jakarta.validation.Valid;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }
    @PostMapping("/create")
    public void createUser(@RequestBody @Valid CreateUserRequest createUserRequest) throws JsonProcessingException {
        userService.create(Utils.convertUserCreateRequest(createUserRequest));
    }

    /*Profile Information*/
    @GetMapping("/profile-info")
    public GetUserResponse getProfile() {
        // getting the object of logged-in user from the security context
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal(); // this statement retrieves the authenticated user from the security context
        // SecurityContextHolder is a class that holds the security context of the current thread
        // getAuthentication() returns the Authentication object which contains the user details
        // getPrincipal() returns the principal object which is the authenticated user
        // so we can get the user details from the principal object
        user = userService.getById(user.getId()); // we are getting the user details from the database using the user id
        return Utils.convertToGetUserResponse(user); // this method converts the User entity to GetUserResponse DTO
    }
    //to be used by the other services for authentication using open feign client
    @GetMapping(value = "/username/{username}" , produces = "application/json")
    public User getUserByUsername(@PathVariable("username")  String username) {
        return   (User) userService.loadUserByUsername(username);
    }
}