package com.major.userservice.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class User implements UserDetails, Serializable { // why it implements UserDetails and Serializable
    // because it is used for authentication and authorization in Spring Security
    // UserDetails is an interface that provides core user information
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id; // This is the primary key
    private String name;// This is the name of the user
    private String email;
    //why we add this field
    //
    private String username;
    private String password;


    private String authorities;

    private int age;
    @CreationTimestamp
    private Date createdAt;
    @UpdateTimestamp
    private Date updatedAt;


    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() { // about this method
        // This method is used to get the authorities of the user
        // The authorities are stored as a string in the format "role1::role2::role3"

        return Arrays.stream(this.authorities.split("::"))
                .map(SimpleGrantedAuthority::new)
                .toList();
    }


}
