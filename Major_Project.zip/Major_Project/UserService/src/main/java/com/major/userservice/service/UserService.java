package com.major.userservice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.major.userservice.dao.UserRepository;
import com.major.userservice.models.User;
//import org.json.JSONObject;
import  org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService implements UserDetailsService {
     // This means to get the bean called userRepository
    @Autowired
    private UserRepository userRepository;
@Autowired
    private PasswordEncoder passwordEncoder;
@Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException { // with the help
        // of this method we can load the user by username
        return userRepository.findByUsername(username);
    }
    public void create(User user){
        ObjectMapper objectMapper = new ObjectMapper(); // this is used to convert the user object to json
        // and send it to the kafka topic

//        userRepository.save(user);
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setAuthorities("usr"); // This is the role of the user
        userRepository.save(user);
        JSONObject userJson = new JSONObject(); // this is used to create a json object
        // we will send this json object to the kafka topic
        userJson.put("phone", user.getUsername());
        userJson.put("email", user.getEmail());

        // publish the user data to the kafka topic-> user-created
        try {
            kafkaTemplate.send("user-created", objectMapper.writeValueAsString(userJson)); // this will send the user data to the kafka topic
            // stringify the userJson object to json string means
            // convert the userJson object to json string
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e.getMessage());
        }
    }


    public  User getById(Integer userId){
        // we will introduce redis caching later
        // for now we will just get the user by id from the database
        return userRepository.findById(userId).orElseThrow(()->new BadCredentialsException("User not found"));
    }

}
