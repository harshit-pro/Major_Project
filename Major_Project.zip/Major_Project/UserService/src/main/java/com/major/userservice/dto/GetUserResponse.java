package com.major.userservice.dto;

import lombok.*;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GetUserResponse {

    private String name;;
    private String email;
    private String mobile;
    private Integer age;
    private Date createdAt;
    private Date updatedAt;
}
